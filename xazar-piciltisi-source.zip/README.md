# Xəzər Pıçıltısı

> An **AI-assisted vibe-coding portfolio project**. The website was created with AI tools from a project brief and creative direction; it is not presented as hand-coded entirely by the owner.

Xəzər Pıçıltısı is a fictional coastal cabin retreat concept set between Nabran’s pine forest and the Caspian Sea. The portfolio website uses Azerbaijani as its default language, with Russian and English options.

## What is included

- Responsive React website with subtle motion
- Azerbaijani, Russian, and English language options
- Cabin cards, photo gallery, FAQs, and a sample booking flow
- Original logo and visual assets for this concept

## Important

This is a portfolio concept, not a real hotel booking service. The property, prices, availability, amenities, and location details are illustrative. The booking form only demonstrates the interaction; it does not send or store guest information. Some imagery was AI-generated for the concept.

## Built with

React 19, TypeScript, TanStack Start, Tailwind CSS, Bun, and Cloudflare Workers.

## Run locally

```sh
bun install
bun run dev
```

Create a production build with `bun run build`. To deploy the Worker from an account with Cloudflare access, run:

```sh
bunx wrangler deploy --config wrangler.workers.jsonc
```

The live portfolio concept is hosted at [xazar-piciltisi.xezernagmesi.workers.dev](https://xazar-piciltisi.xezernagmesi.workers.dev/).
