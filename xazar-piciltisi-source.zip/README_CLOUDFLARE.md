# Cloudflare deployment

This project is configured as a React/TanStack Start app served by a Cloudflare Worker.

1. Install Bun.
2. Run `bun install`.
3. Run `bun run build`.
4. Sign in to Cloudflare with `bunx wrangler login`.
5. Deploy with `bunx wrangler deploy --config wrangler.workers.jsonc`.

The Worker name is `xazar-piciltisi`. Cloudflare combines the Worker name with the account's `workers.dev` subdomain. The current live address is `https://xazar-piciltisi.xezernagmesi.workers.dev/`.

The booking flow is illustrative and does not create real reservations or save guest details.
