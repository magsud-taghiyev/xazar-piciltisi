# Project brief — Xəzər Pıçıltısı

A fictional boutique cabin retreat near Nabran, Azerbaijan, between the pine forest and the Caspian shore. The visual direction is calm, editorial, and coastal, with pine green, sea glass, salt white, and soft citron accents. Azerbaijani is the default language, with Russian and English available.

The booking form demonstrates date and cabin selection with an illustrative price estimate and client-side confirmation. It does not submit or retain personal information. Property names, prices, amenities, and location details are fictional.

This is an AI-assisted vibe-coding portfolio project.
